import 'package:flutter/material.dart';

void main() {
  runApp(const PaytmWalletApp());
}

class PaytmWalletApp extends StatelessWidget {
  const PaytmWalletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Paytm Wallet',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Paytm Wallet"),
      ),
      body: Column(
        children: [

          const SizedBox(height: 20),

          Card(
            margin: const EdgeInsets.all(16),
            child: const Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Text("Available Balance"),
                  SizedBox(height: 10),
                  Text(
                    "₹3,200",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
          ),

          ElevatedButton(
            onPressed: () {},
            child: const Text("Send Money"),
          ),

          ElevatedButton(
            onPressed: () {},
            child: const Text("Receive Money"),
          ),

          ElevatedButton(
            onPressed: () {},
            child: const Text("Add Money"),
          ),

        ],
      ),
    );
  }
}